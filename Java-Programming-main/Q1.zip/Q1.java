import java.util.Scanner;

class Department {
    private String departmentName;
    private String hodName;

    public Department(String departmentName, String hodName) {
        this.departmentName = departmentName;
        this.hodName = hodName;
    }

    public void printDepartmentDetails() {
        System.out.println("Department Name: " + departmentName);
        System.out.println("HOD Name: " + hodName);
    }
}

class StaffMember extends Department {
    private String staffName;
    private String staffQualification;

    public StaffMember(String departmentName, String hodName, String staffName, String staffQualification) {
        super(departmentName, hodName);
        this.staffName = staffName;
        this.staffQualification = staffQualification;
    }

    public void printStaffDetails() {
        super.printDepartmentDetails();
        System.out.println("Staff Name: " + staffName);
        System.out.println("Staff Qualification: " + staffQualification);
    }
}

public class Q1 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.println("Enter Department Name:");
        String departmentName = scanner.nextLine();

        System.out.println("Enter HOD Name:");
        String hodName = scanner.nextLine();

        System.out.println("Enter Staff Name:");
        String staffName = scanner.nextLine();

        System.out.println("Enter Staff Qualification:");
        String staffQualification = scanner.nextLine();

        StaffMember staffMember = new StaffMember(departmentName, hodName, staffName, staffQualification);
        staffMember.printStaffDetails();
    }
}
